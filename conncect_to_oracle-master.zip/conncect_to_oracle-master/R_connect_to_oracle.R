# Set JAVA_HOME, set max. memory, and load rJava library
Sys.setenv(JAVA_HOME='/path/to/java_home')
options(java.parameters="-Xmx2g")
library(rJava)

# Output Java version
.jinit()
print(.jcall("java/lang/System", "S", "getProperty", "java.version"))

# Load RJDBC library
library(RJDBC)

# Create connection driver and open connection
jdbcDriver <- JDBC(driverClass="oracle.jdbc.OracleDriver", classPath="lib/ojdbc6.jar")
jdbcConnection <- dbConnect(jdbcDriver, "jdbc:oracle:thin:@//udwh-prod1.msk.russb.org:1521/udwhprod.msk.russb.org", "Risk", "Risk123")
# udwh-prod1.msk.russb.org
# jdbcConnection <- dbConnect(jdbcDriver, "jdbc:oracle:thin:@//database.hostname.com:port/service_name_or_sid", "username", "password")

# Query on the Oracle instance name.
instanceName <- dbGetQuery(jdbcConnection, "select * from pmg_delays OFFSET 20 ROWS FETCH NEXT 10 ROWS ONLY")
print(instanceName)

# Close connection
dbDisconnect(jdbcConnection)
