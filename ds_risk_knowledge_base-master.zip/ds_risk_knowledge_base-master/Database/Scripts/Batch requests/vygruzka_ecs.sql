drop table ecs_ids;
create table ecs_ids as
select request_id from risk.kva_req_data_prod k
where k.stage in ('�����', '�������','����� �� ��������','����� ������� ����� ���������') 
and to_char(request_id) not in (select app_id from risk.rgsb_5score_sample)
and request_id not in (select req.req_id from equifax_5score_subrequest req
                        inner join risk.equifax_5score_0111 ans 
                        on to_number(ans.num) = req.num)
and req_at < '01.02.2021';


drop table ecs_app_data;
create table ecs_app_data as
select
req_id,
req_at,
to_char(ROWNUM)||'_au' as num,
'����' as prod_name,
json_value(req_data,'$.request.passport.last_name') as lastname,
json_value(req_data,'$.request.passport.first_name') as firstname,
json_value(req_data,'$.request.passport.second_name') as middlename,
json_value(req_data,'$.request.passport.birth_date') as birthday,
json_value(req_data,'$.request.passport.birth_place') as birthplace,
1 as doctype,
json_value(req_data,'$.request.passport.series')||json_value(req_data,'$.request.passport.number') as docno,
json_value(req_data,'$.request.passport.issued_at') as docdate,
json_value(req_data,'$.request.passport.issuer') as docplace,
000000                                           as pfno,
json_value(req_data,'$.request.client_inn') as inn,
json_value(req_data,'$.request.actual_address.postal_code') as addr_reg_index,
json_value(req_data,'$.request.actual_address.oneliner') as addr_reg_total,
json_value(req_data,'$.request.actual_address.postal_code') as addr_fact_index,
json_value(req_data,'$.request.actual_address.oneliner') as addr_fact_total,
json_value(req_data,'$.request.passport.gender') as gender,
to_number( replace(json_value(req_data,'$.request.conditions.loan_amount'),'.',',') )  as request_amount,
json_value(req_data,'$.request.phone') as phone
from ods_005.bp_requests r
where req_id in (select request_id from ecs_ids)

union

select
req_id,
req_at,
to_char(ROWNUM)||'_kn' as num,
'��' as prod_name,
json_value(req_data,'$.surname') as lastname,
json_value(req_data,'$.name') as firstname,
json_value(req_data,'$.patronymic') as middlename,
json_value(req_data,'$.birthdate') as birthday,
json_value(req_data,'$.birth_place') as birthplace,
1 as doctype,
json_value(req_data,'$.passport_series')||json_value(req_data,'$.passport_number') as docno,
json_value(req_data,'$.passport_issued_at') as docdate,
json_value(req_data,'$.passport_issuer') as docplace,
000000                                           as pfno,
'' as inn,
json_value(req_data,'$.registration_address.postal_code') as addr_reg_index,
json_value(req_data,'$.registration_address.result') as addr_reg_total,
json_value(req_data,'$.address_de_facto.postal_code') as addr_fact_index,
json_value(req_data,'$.address_de_facto.result') as addr_fact_total,
case when json_value(req_data,'$.sex') = '�'
          then 'male'
     when json_value(req_data,'$.sex') = '�'
          then 'female'
     else null
end gender,
to_number( replace(json_value(req_data,'$.loan_amount_request'),'.',',') ) / 100 as request_amount,
json_value(req_data,'$.mobile_phone') as phone
from ods_005.bp_agreements a
where a.req_id in (select request_id from ecs_ids);

--Finalnaya vygruzka
select 
d.num,
d.lastname,
d.firstname,
d.middlename,
to_date(d.birthday,'YYYY-MM-DD') as birthday,
d.birthplace,
d.doctype,
d.docno,
to_date(d.docdate,'YYYY-MM-DD') as docdate,
d.docplace,
d.pfno,
d.addr_reg_index,
d.addr_reg_total,
d.addr_fact_index,
d.addr_fact_total,
case when d.gender = 'male'
     then 1
     when d.gender = 'female'
     then 2
    else 9
end gender,
case when d.prod_name = '����'
     then '01'
     when d.prod_name = '��'
     then '05'
    else '99'
end cred_type,
'RUR' as cred_currency,
d.request_amount as cred_sum,
least(trunc(sysdate),add_months(trunc(d.req_at),6)) as dateofreport,
'1' as reason,
' ' as reason_text,
'1' as consent,
trunc(d.req_at) as consentdate,
add_months(trunc(d.req_at),6) as consentenddate,
'1' as admcode_inform,
' ' as consent_owner,
case
  when d.inn <> '' then d.inn
  when c.inn is not null then c.inn
  else ''
end as private_inn,
d.phone as phone_mobile,
'' as phone_home,
'' as phone_work
from ecs_app_data d
left join dds.application a
on to_char(d.req_id) = a.application_num
left join dds.client c
on a.client_id = c.id
left join withdrawal_of_consent w 
on w.pass_series||w.pass_number = d.docno
where w.lst_nm is null
