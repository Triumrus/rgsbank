drop table nbki_ids;
create table nbki_ids as
select distinct request_id from risk.kva_req_data_prod k
where k.stage in ('�����', '�������','����� �� ��������','����� ������� ����� ���������') 
and request_id not in (select r.req_id from GVV_NBKI_RET r)
and request_id not in (select app_id from GVV_NBKI_SAMPLE)
and (k.product_group = '������ ���������' or k.req_at <= '19.01.2021')
and req_at < '01.02.2021';


drop table nbki_smart_ids;
create table nbki_smart_ids as
select distinct k.request_id
from risk.kva_req_data_prod k
where k.product_group <> '������ ���������'
and k.stage in ('�������','����� �� ��������','����� ������� ����� ���������')
and k.num_dog is null
and k.req_at >= '01.05.2020'
and k.req_at < '01.12.2020';

drop table nbki_smart_repeated;
create table nbki_smart_repeated as
select distinct n.request_id from nbki_smart_ids n
left join dds.application a1
on to_char(n.request_id) = a1.application_num
left join dds.application a2
on a1.client_id = a2.client_id
and trunc(a1.appl_create_date) < trunc(a2.appl_create_date) + 1
and add_months(trunc(a1.appl_create_date), 1) > trunc(a2.appl_create_date)
left join risk.kva_req_data_prod k
on to_char(k.request_id) = a2.application_num
where k.num_dog is not null;

drop table nbki_smart_norep;
create table nbki_smart_norep as
select distinct request_id from nbki_smart_ids
where request_id not in (select request_id from nbki_smart_repeated);

drop table nbki_app_data;
create table nbki_app_data as
select
req_id,
trunc(req_at) as retro_date,
to_char(ROWNUM)||'_au' as id,
json_value(req_data,'$.request.passport.last_name') as surname,
json_value(req_data,'$.request.passport.first_name') as name,
json_value(req_data,'$.request.passport.second_name') as patronymic,
json_value(req_data,'$.request.passport.birth_date') as birth_dt,
json_value(req_data,'$.request.passport.series') as passport_ser,
json_value(req_data,'$.request.passport.number') as passport_num,
1 as acct_type,
to_number( replace(json_value(req_data,'$.request.conditions.loan_amount'),'.',',') )  as credit_limit_rub,
to_number(json_value(req_data,'$.request.conditions.credit_term')) as cred_term_month
from ods_005.bp_requests r
--where req_id in (select request_id from nbki_ids)
where req_id in (select request_id from nbki_smart_norep)

union

select
req_id,
trunc(req_at) as retro_date,
to_char(ROWNUM)||'_kn' as id,
json_value(req_data,'$.surname') as surname,
json_value(req_data,'$.name') as name,
json_value(req_data,'$.patronymic') as patronymic,
json_value(req_data,'$.birthdate') as birth_dt,
json_value(req_data,'$.passport_series') as passport_ser,
json_value(req_data,'$.passport_number') as passport_num,
9 as acct_type,
to_number( replace(json_value(req_data,'$.loan_amount_request'),'.',',') ) / 100 as credit_limit_rub,
to_number(json_value(req_data,'$.loan_term_request')) as cred_term_month
from ods_005.bp_agreements a
--where a.req_id in (select request_id from nbki_ids);
where req_id in (select request_id from nbki_smart_norep)


--Finalnaya vygruzka
select 
d.id,
d.passport_ser,
d.passport_num,
d.surname,
d.name,
d.patronymic,
to_date(d.birth_dt,'YYYY-MM-DD') as birth_dt,
d.retro_date,
case
  when k.stage in ('�����', '�������','����� ������� ����� ���������')  then 1
  else 0
end as loan_given,
d.acct_type,
add_months(d.retro_date, d.cred_term_month) - d.retro_date as credit_period_days,
d.credit_limit_rub
from nbki_app_data d
left join risk.kva_req_data_prod k
on d.req_id = k.request_id
left join withdrawal_of_consent w 
on w.pass_series = d.passport_ser 
and w.pass_number = d.passport_num
where w.lst_nm is null

select n.req_id, n.id from nbki_app_data n

