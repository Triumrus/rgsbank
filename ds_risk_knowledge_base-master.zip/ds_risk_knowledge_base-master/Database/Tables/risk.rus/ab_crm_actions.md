# Таблица ab_crm_actions


## Поля

1. sysid_dog - sysid_dog родительский