1. SHOW_NA - Показывает пустые значения в DataFrame (На вход ожидает DataFrame)
2. ALL_GL_GINI -Расчет GINI по скорам и периодам
