- analyses - аналитические функции
- feature_engineering - обработка фичей
- model_engineering - функции для построения моделей

