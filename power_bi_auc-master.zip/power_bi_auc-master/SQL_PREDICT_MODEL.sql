--create or replace view Kuz_model_KN as 
with jjjj as (
select a.* 
,
case when a.PRE_30_0_6 is null then 0.5169 else a.PRE_30_0_6 end PRE_30_0_6_2,
case when a.education = '������' then 1 else 0 end EDUCATION_������,
case when a.FAMILY = '����� / �������' then 1 else 0 end FAMILY_�����_�������,
case when a.RULE_2_15 = 1 then 1 
  when a.RULE_2_15 is null then 0.006263499
  else 0 end RULE_2_15_1,
case when a.RULE_2_27 = 1 then 1 
     when a.RULE_2_27 is null then 0.695032397
     else 0 end RULE_2_27_1,
case when a.AGE < 31 then 1 else 0 end AGE_1,
case when a.AGE > 57  then 1 else 0 end AGE_4,


((case when SCORE_OKB is null then 841 else to_number(SCORE_OKB) end  -8.27159640e+02)/1.84147850e+02)+15 as SCORE_OKB_r,
((case when SCORE_EQUIFAX is null then 684 else to_number(SCORE_EQUIFAX) end -6.87028308e+02)/6.78410497e+01)+15 as SCORE_EQUIFAX_r,
((case when EQUIFAX_COS is null then 0.3488054 else to_number(EQUIFAX_COS) end -8.70905809e-01)/1.69580456e+00)+15 as EQUIFAX_COS_r,
((case when OKB_COS is null then 0.6408885 else to_number(OKB_COS) end -1.28063337e+00)/2.18028142e+00)+15 as OKB_COS_r,
case when a.HISTORY_QUALITY = 'NO_HIST' then 
  (((case when a.megafon_score is null then 0.1003110 else to_number(a.megafon_score) end *-1)+1.03570114e-01)/3.54610761e-02)+15
  
else
((1+(((case when EQUIFAX_COS is null then 0.3488054 else to_number(EQUIFAX_COS) end-8.70905809e-01)/1.69580456e+00)+15))*(((case when SCORE_EQUIFAX is null then 684 else to_number(SCORE_EQUIFAX) end-6.87028308e+02)/6.78410497e+01)+15)+(1+(((case when OKB_COS is null then 0.6408885 else to_number(OKB_COS) end-1.28063337e+00)/2.18028142e+00)+15))*(((case when SCORE_OKB is null then 841 else to_number(SCORE_OKB) end-8.27159640e+02)/1.84147850e+02)+15))/((1+(((case when EQUIFAX_COS is null then 0.3488054 else to_number(EQUIFAX_COS) end-8.70905809e-01)/1.69580456e+00)+15))+(1+(((case when OKB_COS is null then 0.6408885 else to_number(OKB_COS) end-1.28063337e+00)/2.18028142e+00)+15))) 
end 
--AS
optifun_2
,
case when CNT_6_PAYCASH is null or CNT_7_12_PAYCASH is null or CNT_ACTIVE is null then -0.331026658
  else
  ((((CNT_6_PAYCASH+CNT_7_12_PAYCASH)-32.92106736)/22.07255303)*0.70710678)+(((CNT_ACTIVE-3.6773067)/2.33153731)*0.70710678) 
  -- as 
  end  PCA_1,
case when CNT_6_PAYCASH is null or CNT_7_12_PAYCASH is null or CNT_ACTIVE is null then 0.079799416
     else 
((((CNT_6_PAYCASH+CNT_7_12_PAYCASH)-32.92106736)/22.07255303)*0.70710678)+(((CNT_ACTIVE-3.6773067)/2.33153731)*-0.70710678) 
  --as 
  end  PCA_2



from kuz_big_table a
)
select

a.*,

 1/(1+exp(
(PRE_30_0_6_2*0.10687449696830398+
EDUCATION_������*-0.5531374851745071+
FAMILY_�����_�������*-0.5497619694985825+
RULE_2_15_1*0.7897368141250564+
RULE_2_27_1*0.7587781299033723+
AGE_1*-0.08846988039495429+
AGE_4*0.14995372244886293+
optifun_2*-0.23143037463294122+
PCA_1*-0.1382824282964586+
PCA_2*-0.9049326675590973)*-1
)) as PD


from jjjj a
 

