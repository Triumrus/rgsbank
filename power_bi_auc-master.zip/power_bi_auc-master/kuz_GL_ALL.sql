--create or replace view  kuz_GL_ALL as 
with GL as ( 
select  
req_id, 
case when gl_days_pros >= 30 and mob = 3 then 1 when gl_days_pros < 30 and mob = 3 then 0 when gl_days_pros is null and mob = 3 then 0 else null  end GL30_3, 
case when gl_days_pros >= 60 and mob = 3 then 1 when gl_days_pros < 60 and mob = 3 then 0 when gl_days_pros is null and mob = 3 then 0 else null  end GL60_3, 
case when gl_days_pros >= 90 and mob = 3 then 1 when gl_days_pros < 90 and mob = 3 then 0 when gl_days_pros is null and mob = 3 then 0 else null  end GL90_3, 
case when gl_days_pros >= 30 and mob = 6 then 1 when gl_days_pros < 30 and mob = 6 then 0 when gl_days_pros is null and mob = 6 then 0 else null  end GL30_6,
case when gl_days_pros >= 30 and mob = 5 then 1 when gl_days_pros < 30 and mob = 5 then 0 when gl_days_pros is null and mob = 5 then 0 else null  end GL30_5, 
case when gl_days_pros >= 60 and mob = 6 then 1 when gl_days_pros < 60 and mob = 6 then 0 when gl_days_pros is null and mob = 6 then 0 else null  end GL60_6, 
case when gl_days_pros >= 90 and mob = 6 then 1 when gl_days_pros < 90 and mob = 6 then 0 when gl_days_pros is null and mob = 6 then 0 else null  end GL90_6, 
case when gl_days_pros >= 30 and mob = 9 then 1 when gl_days_pros < 30 and mob = 9 then 0 when gl_days_pros is null and mob = 6 then 0 else null  end GL30_9, 
case when gl_days_pros >= 60 and mob = 9 then 1 when gl_days_pros < 60 and mob = 9 then 0 when gl_days_pros is null and mob = 6 then 0 else null  end GL60_9, 
case when gl_days_pros >= 90 and mob = 9 then 1 when gl_days_pros < 90 and mob = 9 then 0 when gl_days_pros is null and mob = 6 then 0 else null  end GL90_9, 
case when gl_days_pros >= 30 and mob = 12 then 1 when gl_days_pros < 30 and mob = 12 then 0 when gl_days_pros is null and mob = 6 then 0 else null  end GL30_12, 
case when gl_days_pros >= 60 and mob = 12 then 1 when gl_days_pros < 60 and mob = 12 then 0 when gl_days_pros is null and mob = 6 then 0 else null  end GL60_12, 
case when gl_days_pros >= 90 and mob = 12 then 1 when gl_days_pros < 90 and mob = 12 then 0 when gl_days_pros is null and mob = 6 then 0 else null  end GL90_12 
from risk.pmg_delays 
where 1=1 
--and mob in (3,6,9,12) 
and req_id is not null 
)
, GL_ALL as (
select req_id, 
sum(GL30_3) as GL30_3, 
sum(GL60_3) as GL60_3, 
sum(GL90_3) as GL90_3, 
sum(GL30_6) as GL30_6,
sum(GL30_5) as GL30_5, 
sum(GL60_6) as GL60_6, 
sum(GL90_6) as GL90_6, 
sum(GL30_9) as GL30_9, 
sum(GL60_9) as GL60_9, 
sum(GL90_9) as GL90_9, 
sum(GL30_12) as GL30_12, 
sum(GL60_12) as GL60_12, 
sum(GL90_12) as GL90_12 
from GL 
group by req_id )
select * from GL_ALL
--where req_id= '3017646'
