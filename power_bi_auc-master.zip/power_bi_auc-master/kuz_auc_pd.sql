--create or replace view kuz_auc_pd as
with auc as (
select 
req_at,
OKB_SCORE,
EQuifax_score,
megafon_score,
PD,
GL30_5

 from  auto_pd a
inner join   GL_ALL  b
on to_char(a.req_id) = b.req_id
where 1=1
and req_at >= to_date('2019-10-01','yyyy-mm-dd')
), T as (
  SELECT req_at,GL30_5 as label, 
  row_number() OVER (partition by extract(month from req_at),extract(year from req_at) ORDER BY PD) PD,
  row_number() OVER (partition by extract(month from req_at),extract(year from req_at) ORDER BY OKB_SCORE desc) OKB_SCORE,
  row_number() OVER (partition by extract(month from req_at),extract(year from req_at) ORDER BY EQuifax_score desc) EQuifax_score,
  row_number() OVER (partition by extract(month from req_at),extract(year from req_at) ORDER BY megafon_score) megafon_score
  FROM auc
  where GL30_5 is not null
)

SELECT extract(month from req_at) as mnt,extract(year from req_at) as year_,
(sum(label*PD) - 0.5*sum(label)*(sum(label)+1)) / (sum(label) * sum(1-label)) AS auc_PD,
(sum(label*OKB_SCORE) - 0.5*sum(label)*(sum(label)+1)) / (sum(label) * sum(1-label)) AS auc_OKB_SCORE,
(sum(label*EQuifax_score) - 0.5*sum(label)*(sum(label)+1)) / (sum(label) * sum(1-label)) AS auc_EQuifax_score,
(sum(label*megafon_score) - 0.5*sum(label)*(sum(label)+1)) / (sum(label) * sum(1-label)) AS auc_megafon_score
FROM T
group by extract(month from req_at),extract(year from req_at)
order by 2,1
;
