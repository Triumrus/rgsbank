create or replace view kuz_auto_pd as 
with data_predict as (
select --a.*,
c.req_id,
c.req_at,
c.score_okb   as OKB_SCORE,
c.score_equifax as EQUIFAX_SCORE,
c.megafon_score,
case when c.equifax_cos  = 0 then 1 else 0 end FACT_EQUIFAX_COS_1,
case when c.score_okb = 0 then 1 else 0 end OKB_SCORE_0,
c.initial_payment/MAIN_INCOME as PV_INCOME,
case when GENDER = 'male' then 1 else 0 end GENDER_male,
case when FAMILY = '∆енат / замужем' then 1 else 0 end FAMILY
/*from for_razmetka a
left join KUZ_SCORE_APP_ID b
on a.app_id = b.app_id*/
from  kuz_big_table c
where product_id != 'КН'
and status = 'Выдан'
--on a.app_id = c.req_id
--where a.app_id = 3003520
)
,PD as (
select 
a.*, 
OKB_SCORE*-0.0022552960435673532 as PD_score_okb,
EQUIFAX_SCORE*-0.005408789739817657 as PD_EQUIFAX_SCORE,
MEGAFON_SCORE*5.479957361728502 as PD_MEGAFON_SCORE,
FACT_EQUIFAX_COS_1*0.8663859632054861 as PD_FACT_EQUIFAX_COS_1,
OKB_SCORE_0*-1.6698186871728273 as PD_OKB_SCORE_0,
PV_INCOME*-0.11907608464596377 as PD_PV_INCOME,
GENDER_male*0.6757539080097434 as PD_GENDER_male,
FAMILY*-0.7315511180670936 as PD_FAMILY,
0.7989436468977208 as intercept


from data_predict a
where 1=1
and  OKB_SCORE is not null
and  EQUIFAX_SCORE is not null
and  MEGAFON_SCORE is not null
and  FACT_EQUIFAX_COS_1 is not null
and  PV_INCOME is not null

)

select a.*,
EXP(PD_score_okb+PD_EQUIFAX_SCORE+PD_MEGAFON_SCORE+PD_FACT_EQUIFAX_COS_1+PD_OKB_SCORE_0+PD_PV_INCOME+PD_GENDER_male+PD_FAMILY+intercept)/
(EXP(PD_score_okb+PD_EQUIFAX_SCORE+PD_MEGAFON_SCORE+PD_FACT_EQUIFAX_COS_1+PD_OKB_SCORE_0+PD_PV_INCOME+PD_GENDER_male+PD_FAMILY+intercept)+1) as PD



from PD a


;



