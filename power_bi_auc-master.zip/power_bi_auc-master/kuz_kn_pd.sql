--create or replace view kuz_kn_pd as 
with auc as (
select 
a.req_at,
--a.OKB_SCORE,
to_number(a.score_okb) as OKB_SCORE,
--a.equifax_score,
to_number(a.score_equifax) as equifax_score,
a.megafon_score,
PD,
GL30_3

 from  kuz_big_table a 
inner join   GL_ALL  b
on to_char(a.req_id) = b.req_id
left join Kuz_model_KN c
on a.req_id = c.REQ_ID
where 1=1
and a.req_at >= to_date('2019-10-01','yyyy-mm-dd')
and a.product_id = 'КН'
), T as (
  SELECT req_at,GL30_3 as label, 
  row_number() OVER (partition by extract(month from req_at),extract(year from req_at) ORDER BY PD) PD,
  row_number() OVER (partition by extract(month from req_at),extract(year from req_at) ORDER BY OKB_SCORE desc) OKB_SCORE,
  row_number() OVER (partition by extract(month from req_at),extract(year from req_at) ORDER BY EQuifax_score desc) EQuifax_score,
  row_number() OVER (partition by extract(month from req_at),extract(year from req_at) ORDER BY megafon_score) megafon_score
  FROM auc
  where GL30_3 is not null
)

SELECT extract(month from req_at) as mnt,extract(year from req_at) as year_,
(sum(label*PD) - 0.5*sum(label)*(sum(label)+1)) / (sum(label) * sum(1-label)) AS auc_PD,
(sum(label*OKB_SCORE) - 0.5*sum(label)*(sum(label)+1)) / (sum(label) * sum(1-label)) AS auc_OKB_SCORE,
(sum(label*EQuifax_score) - 0.5*sum(label)*(sum(label)+1)) / (sum(label) * sum(1-label)) AS auc_EQuifax_score,
(sum(label*megafon_score) - 0.5*sum(label)*(sum(label)+1)) / (sum(label) * sum(1-label)) AS auc_megafon_score
FROM T
group by extract(month from req_at),extract(year from req_at)
order by 2,1
